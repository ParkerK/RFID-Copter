/*
 * Board_APM1_2560.cpp
 *
 *  Created on: Dec 7, 2011
 *
 */

#include "Board_APM1_2560.h"

namespace apo {

} // namespace apo

// vim:ts=4:sw=4:expandtab
