
#define WDTO_15MS 15

#define wdt_enable(x)
