
#ifndef __AP_ANALOG_SOURCE_H__
#define __AP_ANALOG_SOURCE_H__

#include "AP_AnalogSource_Arduino.h"
#include "AP_AnalogSource_ADC.h"

#endif // __AP_ANALOG_SOURCE_H__
